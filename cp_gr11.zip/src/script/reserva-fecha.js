src="https://cdnjs.cloudflare.com/ajax/libs/date-fns/2.27.0/date-fns.min.js"
document.addEventListener("DOMContentLoaded", function() {
    let calendarioDiv = document.getElementById("calendario");
    let fechaActual = new Date();
    let fechaActualReal = new Date();

    function obtenerFechasReservadas() {
      let reservadas = getCookie("fechasReservadas");
      return reservadas ? JSON.parse(reservadas) : [];
    }

    function construirCalendario(mes, anio) {
      calendarioDiv.innerHTML = "";
      
      let encabezadoMes = document.createElement("p");
      let diasMes = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
                    "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
      encabezadoMes.innerHTML = diasMes[mes] +" "+ anio;
      calendarioDiv.appendChild(encabezadoMes)
      
      let tabla = document.createElement("table");
      
      let encabezado = tabla.createTHead();
      let filaEncabezado = encabezado.insertRow();
      let diasSemana = ["L", "M", "X", "J", "V", "S", "D"];

      for (let i = 0; i < diasSemana.length; i++) {
        let celda = document.createElement("th");
        celda.innerHTML = diasSemana[i];
        filaEncabezado.appendChild(celda);
      }

      let primerDia = new Date(anio, mes, 1);
      let ultimoDia = new Date(anio, mes + 1, 0);
      let diaActual = 1;
      let diaSemana = (primerDia.getDay()+6)%7;
      let ultimaFila = tabla.insertRow();

      let fechasReservadas = obtenerFechasReservadas();

      for (let i = 0; i < 6 * 7; i++) {
        let celda = ultimaFila.insertCell();

        if (i < diaSemana || diaActual > ultimoDia.getDate()) {
          celda.innerHTML = "&nbsp;";
        } else {
          celda.innerHTML = diaActual;
          let fecha = new Date(anio, mes, diaActual);
            if (fecha < fechaActualReal || fechasReservadas.includes(fecha.toDateString())){
                celda.style.backgroundColor ="rgb(103, 103, 103,0.5)";
                celda.style.borderRadius = "50%";
                celda.style.textDecoration = "line-through";
            } else {
                celda.addEventListener("click", function() {
                  let diaSeleccionado = this.innerHTML;
                  let fechaSeleccionada = new Date(fechaActual.getFullYear(), fechaActual.getMonth(), diaSeleccionado);
      
                  if (fechaSeleccionada > fechaActualReal) {
                      sessionStorage.setItem("fechaSeleccionada", fechaSeleccionada.toDateString()); 
                      window.location.href="../pestañas/reservar-mesa.html";
                  }
              });
            }
          diaActual++;
        }

        if (i % 7 === 6) {
          ultimaFila = tabla.insertRow();
        }
      }

      calendarioDiv.appendChild(tabla);
    }

    function mostrarCalendario(mes, anio) {
      construirCalendario(mes, anio);

      let botonAnterior = document.createElement("button");
        botonAnterior.id = "btnAnterior";
        let imgAnterior = document.createElement("img");
        imgAnterior.src = "../imagenes/flecha-calendario_izquierda.png";
        botonAnterior.appendChild(imgAnterior);
        botonAnterior.addEventListener("click", function() {
            fechaActual.setMonth(fechaActual.getMonth() - 1);
          if (fechaActual >= fechaActualReal){
            mostrarCalendario(fechaActual.getMonth(), fechaActual.getFullYear());
          }else{
            fechaActual.setMonth(fechaActual.getMonth() + 1);
          }
        });
        calendarioDiv.appendChild(botonAnterior);

        // Botón para ir al mes siguiente
        let botonSiguiente = document.createElement("button");
        botonSiguiente.id = "btnSiguiente";
        let imgSiguiente = document.createElement("img");
        imgSiguiente.src = "../imagenes/flecha-calendario_derecha.png";
        botonSiguiente.appendChild(imgSiguiente);
        botonSiguiente.addEventListener("click", function() {
            fechaActual.setMonth(fechaActual.getMonth() + 1);
            if (fechaActual <= fechaActualReal.setMonth(fechaActualReal.getMonth() + 2)) {
              fechaActualReal.setMonth(fechaActualReal.getMonth()-2);
              mostrarCalendario(fechaActual.getMonth(), fechaActual.getFullYear());
            } else {
              fechaActualReal.setMonth(fechaActualReal.getMonth()-2)
              fechaActual.setMonth(fechaActual.getMonth() - 1);
            }
        });
        calendarioDiv.appendChild(botonSiguiente);
    }

    mostrarCalendario(fechaActual.getMonth(), fechaActual.getFullYear());
  });

  function setCookie(name, value, seconds) {
    let expires = "";
    if (seconds) {
        let date = new Date();
        date.setTime(date.getTime() + (seconds * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    let cookie = name + "=" + encodeURIComponent(value);
    document.cookie = cookie;
}

function getCookie(name) {
    let cookieArr = document.cookie.split(";");

    for(let i = 0; i < cookieArr.length; i++) {
        let cookiePair = cookieArr[i].split("=");
        if(name == cookiePair[0].trim()) {
            return decodeURIComponent(cookiePair[1]);
        }
    }

    return null;
}