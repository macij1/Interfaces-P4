function submitLoginForm(event) {
    event.preventDefault();

    // Obtener valores de nombre de usuario y contraseña
    let userName = document.getElementById("userNameLogin").value;
    let password = document.getElementById("passwordLogin").value;

    // Obtener la lista de usuarios registrados
    let usuariosRegistrados = obtenerRegistro();

    // Verificar si el usuario y la contraseña son válidos
    let usuarioValido = usuariosRegistrados.find(usuario => usuario.username === userName && usuario.contrasena === password);

    if (usuarioValido) {
        let datosUsuario = {
            nombre: usuarioValido.nombre,
            apellido: usuarioValido.apellido,
            telefono: usuarioValido.telefono,
            correo: usuarioValido.correo
        };
        sessionStorage.setItem("usuario", JSON.stringify(datosUsuario));
        sessionStorage.setItem("sesionIniciada", true); 
        window.location.href = "../pagina-inicio.html";
    } else {
        alert("Nombre de usuario o contraseña incorrectos. Por favor, inténtelo de nuevo.");
    }
}

function obtenerRegistro() {
    let registrados = getCookie("usuariosRegistrados");
    return registrados ? JSON.parse(registrados) : [];
}

function getCookie(name) {
    let cookieName = name + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let cookieArray = decodedCookie.split(';');
    for (let i = 0; i < cookieArray.length; i++) {
        let cookie = cookieArray[i].trim();
        if (cookie.indexOf(cookieName) === 0) {
            return cookie.substring(cookieName.length, cookie.length);
        }
    }
    return null;
}
