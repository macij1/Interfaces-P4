document.addEventListener('DOMContentLoaded', () => {
    let sesion = sessionStorage.getItem("sesionIniciada");
    if(sesion){
        window.location.href = "../pestañas/reservar-final.html";
    }
});

function setSessionData(name, value) {
    sessionStorage.setItem(name, JSON.stringify(value));
}

function getSessionData(name) {
    let data = sessionStorage.getItem(name);
    return data ? JSON.parse(data) : {};
}

function guardarDatosUsuario() {
    let userData = getSessionData("usuario");

    let nombreInput = document.getElementById("name");
    let apellidoInput = document.getElementById("surname");
    let telefonoInput = document.getElementById("phone");
    let correoInput = document.getElementById("email");

    let nombrePattern = /^[A-Za-zÀ-ÿ\u00f1\u00d1 ]+$/;
    let apellidoPattern = /^[A-Za-z ]+$/;
    let telefonoPattern = /^[0-9]{9}$/;
    let correoPattern = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;

    if (nombrePattern.test(nombreInput.value)) {
        userData.nombre = nombreInput.value;
    }

    if (apellidoPattern.test(apellidoInput.value)) {
        userData.apellido = apellidoInput.value;
    }

    if (telefonoPattern.test(telefonoInput.value)) {
        userData.telefono = telefonoInput.value;
    }

    if (correoPattern.test(correoInput.value)) {
        userData.correo = correoInput.value;
    }

    setSessionData("usuario", userData);
}

document.getElementById("formulario").addEventListener("submit", function (e) {
    e.preventDefault();
    e.stopPropagation();

    guardarDatosUsuario();
    
    window.location.href = "reservar-final.html";
});
