document.addEventListener("DOMContentLoaded", function() {
    let video = document.getElementById('video-background');
    let pauseButton = document.getElementById('video-pause');
    let playButton = document.getElementById('video-play');
    let replayButton = document.getElementById('video-replay'); 
    playButton.style.display = 'none';

    pauseButton.addEventListener('click', function() {
        video.pause();
        pauseButton.style.display = 'none';
        playButton.style.display = 'block';
    });

    playButton.addEventListener('click', function() {
        video.play();
        replayButton.style.display = 'block';
        pauseButton.style.display = 'block';
        playButton.style.display = 'none';
    });

    replayButton.addEventListener('click', function() {
        video.currentTime = 0; // Reinicia el video
        video.play();
        pauseButton.style.display = 'none';
        playButton.style.display = 'block';
    });

    let userData = JSON.parse(getCookie("usuario"));
    let fechaActual = getCookie("fechaSeleccionada");

    if (userData) {
        let fechaObj = new Date(fechaActual);
        let dia = fechaObj.getDate();
        let mes = fechaObj.getMonth() + 1; 
        let anio = fechaObj.getFullYear();
        let fechaFormateada = `${dia}/${mes}/${anio}`;

        document.getElementById("nombre").textContent = userData.nombre + " " + userData.apellido;
        document.getElementById("dia-hora").textContent = fechaFormateada + ", " + userData.hora;
        document.getElementById("numero-personas").textContent = userData.numero + " personas";
        document.getElementById("ubicacion").textContent = userData.ubicacion;
    }
});

