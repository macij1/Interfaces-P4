function SaveLocation(ubicacion) {
    sessionStorage.setItem("ubicacion", ubicacion); 
}

function SaveNumber(number) {
    sessionStorage.setItem("numeroPersonas", number);  
}

function SaveTime(time) {
    sessionStorage.setItem("hora", time); 
}


