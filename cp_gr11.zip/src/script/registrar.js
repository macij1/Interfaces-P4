let usuario = {};

function obtenerRegistro() {
    let registrados = getCookie("usuariosRegistrados");
    return registrados ? JSON.parse(registrados) : [];
}

function setCookie(name, value) {
    document.cookie = name + "=" + value + "; path=/";
}

function getCookie(name) {
    let cookieName = name + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let cookieArray = decodedCookie.split(';');
    for (let i = 0; i < cookieArray.length; i++) {
        let cookie = cookieArray[i].trim();
        if (cookie.indexOf(cookieName) === 0) {
            return cookie.substring(cookieName.length, cookie.length);
        }
    }
    return null;
}

function guardarRegistro(usuario) {
    let usuariosRegistrados = obtenerRegistro();
    usuariosRegistrados.push(usuario);
    setCookie("usuariosRegistrados", JSON.stringify(usuariosRegistrados));
}

function validarNombreUsuario() {
    userNameInput = document.getElementById("userName");
    let nuevoUsuario = userNameInput.value;

    // Obtener la lista de usuarios registrados y verificar si el nombre de usuario ya existe
    let usuariosRegistrados = obtenerRegistro();
    let usuarioExistente = usuariosRegistrados.find(usuario => usuario.username === nuevoUsuario);

    if (usuarioExistente) {
        userNameInput.value = ""; 
    } else {
        userNameInput.style.color = 'green';
        usuario.username = nuevoUsuario;
    }
}

function validarContraseña() {
    contrasenaInput = document.getElementById("password");
    let contrasenaPattern = /^[A-Za-z0-9]{2,}$/;
    if (contrasenaPattern.test(contrasenaInput.value)) {
        contrasenaInput.style.color = 'green';
        usuario.contrasena = contrasenaInput.value;
    } else {
        contrasenaInput.style.color ='red';
    }
}

function validarNombre() {
    nombreInput = document.getElementById("name");
    let nombrePattern = /^[A-Za-zÀ-ÿ\u00f1\u00d1 ]+$/;
    if (nombrePattern.test(nombreInput.value)) {
        nombreInput.style.color = 'green';
        usuario.nombre = nombreInput.value;
    } else {
        nombreInput.style.color ='red';
    }
}

function validarApellido() {
    apellidoInput = document.getElementById("surname");
    let apellidoPattern = /^[A-Za-zÀ-ÿ\u00f1\u00d1 ]+$/;
    if (apellidoPattern.test(apellidoInput.value)) {
        apellidoInput.style.color = 'green';
        usuario.apellido = apellidoInput.value;
    } else {
        apellidoInput.style.color = 'red';
    }
}

function validarTelefono() {
    telefonoInput = document.getElementById("phone");
    let telefonoPattern = /^[0-9]{9}$/;
    if (telefonoPattern.test(telefonoInput.value)) {
        telefonoInput.style.color = 'green';
        usuario.telefono = telefonoInput.value;
    } else {
        telefonoInput.style.color = 'red';
    }
}

function validarCorreo() {
    correoInput = document.getElementById("email");
    let correoPattern = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
    if (correoPattern.test(correoInput.value)) {
        correoInput.style.color ='green';
        usuario.correo = correoInput.value;
    } else {
        correoInput.style.color ='red';
    }
}

function submitFormR(event) {
    event.preventDefault();
    guardarRegistro(usuario);
    window.location.href = "../pagina-inicio.html";
}